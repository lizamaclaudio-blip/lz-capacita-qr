import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

export const dynamic = "force-dynamic";

const UUID_RE =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

function isUuid(v: unknown) {
  return typeof v === "string" && UUID_RE.test(v.trim());
}

function getToken(req: NextRequest) {
  const auth = req.headers.get("authorization") || "";
  const m = auth.match(/^Bearer\s+(.+)$/i);
  return m?.[1] || null;
}

function sbAuthed(token: string) {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL!;
  const anon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;
  return createClient(url, anon, {
    global: { headers: { Authorization: `Bearer ${token}` } },
    auth: { persistSession: false },
  });
}

async function requireUser(req: NextRequest) {
  const token = getToken(req);
  if (!token) return { ok: false as const, status: 401, error: "Missing bearer token" };

  const supabase = sbAuthed(token);
  const { data: u, error: uerr } = await supabase.auth.getUser();
  if (uerr || !u?.user) return { ok: false as const, status: 401, error: "Unauthorized" };

  return { ok: true as const, supabase, user: u.user };
}

async function requireOwnedCompany(auth: { supabase: any; user: any }, companyId: string) {
  const { data, error } = await auth.supabase
    .from("companies")
    .select("id, owner_id")
    .eq("id", companyId)
    .eq("owner_id", auth.user.id)
    .maybeSingle();

  if (error || !data) return null;
  return data;
}

type WorkerRow = {
  rut: string;
  full_name: string | null;
  role: string | null;
  last_seen_at: string;
};

export async function GET(req: NextRequest, ctx: { params: { companyId: string } }) {
  try {
    const auth = await requireUser(req);
    if (!auth.ok) return NextResponse.json({ error: auth.error }, { status: auth.status });

    const companyId = ctx.params.companyId;
    if (!isUuid(companyId)) {
      return NextResponse.json({ error: "companyId inválido" }, { status: 400 });
    }

    const owned = await requireOwnedCompany(auth, companyId);
    if (!owned) return NextResponse.json({ error: "Empresa no encontrada o sin acceso" }, { status: 404 });

    // sesiones de la empresa
    const { data: sessions, error: sErr } = await auth.supabase
      .from("sessions")
      .select("id")
      .eq("company_id", companyId)
      .eq("owner_id", auth.user.id);

    if (sErr) return NextResponse.json({ error: sErr.message }, { status: 400 });

    const sessionIds = (sessions ?? []).map((s: any) => s.id).filter(Boolean);
    if (!sessionIds.length) return NextResponse.json({ workers: [] });

    // attendees ordenados por más reciente: tomamos el primero por rut
    const { data: attendees, error: aErr } = await auth.supabase
      .from("attendees")
      .select("rut, full_name, role, created_at, session_id")
      .in("session_id", sessionIds)
      .order("created_at", { ascending: false });

    if (aErr) return NextResponse.json({ error: aErr.message }, { status: 400 });

    const map = new Map<string, WorkerRow>();
    for (const a of attendees ?? []) {
      const rut = String((a as any)?.rut ?? "").trim();
      if (!rut || rut === "undefined" || rut === "null") continue;

      if (!map.has(rut)) {
        map.set(rut, {
          rut,
          full_name: (a as any)?.full_name ?? null,
          role: (a as any)?.role ?? null,
          last_seen_at: (a as any)?.created_at ?? new Date().toISOString(),
        });
      }
    }

    const workers = Array.from(map.values()).sort((x, y) => {
      const xd = new Date(x.last_seen_at).getTime();
      const yd = new Date(y.last_seen_at).getTime();
      return yd - xd;
    });

    return NextResponse.json({ workers });
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || "Server error" }, { status: 500 });
  }
}