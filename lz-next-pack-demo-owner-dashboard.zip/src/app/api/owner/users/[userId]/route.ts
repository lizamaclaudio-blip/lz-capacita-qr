import { NextRequest, NextResponse } from "next/server";
import { requireOwner } from "@/lib/supabase/owner";
import { logOwnerAction } from "@/lib/owner/audit";

export const dynamic = "force-dynamic";
export async function GET(req: NextRequest, ctx: { params: { userId: string } }) {
  const auth = await requireOwner(req);
  if (!auth.ok) return NextResponse.json({ error: auth.error }, { status: auth.status });

  // Next debería pasar params, pero en algunos setups (o llamadas raras con trailing slash)
  // puede venir vacío. Hacemos fallback desde URL/path/query para evitar el "userId is required".
  const url = new URL(req.url);
  const fromQuery = url.searchParams.get("userId") || "";
  const fromPath = (url.pathname.split("/").filter(Boolean).pop() || "").trim();
  const candidate = String(ctx?.params?.userId || "").trim();
  const userId = (candidate || fromQuery || (fromPath !== "users" ? fromPath : "")).trim();
  if (!userId) return NextResponse.json({ error: "userId is required" }, { status: 400 });

  try {
    const { data: userRes, error: uErr } = await auth.sbAdmin.auth.admin.getUserById(userId);
    if (uErr || !userRes?.user) return NextResponse.json({ error: uErr?.message || "User not found" }, { status: 404 });

    const user = userRes.user as any;

    const { data: companies, error: cErr } = await auth.sbAdmin
      .from("companies")
      .select("id, owner_id, name, rut, logo_path, created_at")
      .eq("owner_id", userId)
      .order("created_at", { ascending: false });

    if (cErr) return NextResponse.json({ error: cErr.message }, { status: 400 });

    const { data: sessions, error: sErr } = await auth.sbAdmin
      .from("sessions")
      .select(
        "id, owner_id, company_id, code, topic, location, session_date, created_at, status, closed_at, pdf_path, pdf_generated_at, trainer_signature_path"
      )
      .eq("owner_id", userId)
      .order("created_at", { ascending: false });

    if (sErr) return NextResponse.json({ error: sErr.message }, { status: 400 });

    const sessionIds = (sessions ?? []).map((s: any) => s.id).filter(Boolean);

    const attendeeCounts: Record<string, number> = {};

    if (sessionIds.length) {
      const { data: atts, error: aErr } = await auth.sbAdmin
        .from("attendees")
        .select("session_id, signature_path")
        .in("session_id", sessionIds);

      if (aErr) return NextResponse.json({ error: aErr.message }, { status: 400 });

      for (const r of atts ?? []) {
        const sid = (r as any).session_id;
        if (!sid) continue;
        attendeeCounts[sid] = (attendeeCounts[sid] ?? 0) + 1;
      }
    }

    const outSessions = (sessions ?? []).map((s: any) => ({
      ...s,
      attendees_count: attendeeCounts[s.id] ?? 0,
    }));

    const byCompany: Record<string, any> = {};
    for (const s of outSessions) {
      const cid = String(s.company_id || "");
      if (!cid) continue;
      byCompany[cid] = byCompany[cid] || { sessions: 0, attendees: 0, pdfs: 0 };
      byCompany[cid].sessions += 1;
      byCompany[cid].attendees += Number(s.attendees_count) || 0;
      if (s.pdf_path) byCompany[cid].pdfs += 1;
    }

    const outCompanies = (companies ?? []).map((c: any) => {
      const stats = byCompany[c.id] || { sessions: 0, attendees: 0, pdfs: 0 };
      return { ...c, stats };
    });

    await logOwnerAction(auth.sbAdmin, {
      owner_user_id: auth.user.id,
      owner_email: auth.ownerEmail,
      action: "user_detail",
      target_user_id: userId,
      request_ip: auth.ip,
      request_ua: auth.ua,
      status: 200,
      result: { companies: outCompanies.length, sessions: outSessions.length },
    });

    return NextResponse.json({
      user: {
        id: user.id,
        email: user.email ?? null,
        created_at: user.created_at,
        last_sign_in_at: user.last_sign_in_at ?? null,
        banned_until: user.banned_until ?? null,
        user_metadata: user.user_metadata ?? {},
      },
      companies: outCompanies,
      sessions: outSessions,
    });
  } catch (e: any) {
    await logOwnerAction(auth.sbAdmin, {
      owner_user_id: auth.user.id,
      owner_email: auth.ownerEmail,
      action: "user_detail",
      target_user_id: userId,
      request_ip: auth.ip,
      request_ua: auth.ua,
      status: 500,
      result: { error: e?.message || "error" },
    });

    return NextResponse.json({ error: e?.message || "Server error" }, { status: 500 });
  }
}
