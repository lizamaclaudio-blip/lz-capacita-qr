// Por ahora vacío: después lo usamos si quieres notificaciones, archivos, etc.
