export default function DashboardPage() {
  return (
    <div>
      <h1 style={{ fontSize: 20, fontWeight: 800 }}>Dashboard</h1>
      <p style={{ marginTop: 8, color: "#0866eb" }}>
        Panel principal. Después aquí ponemos resumen (empresas, charlas, PDFs).
      </p>
    </div>
  );
}