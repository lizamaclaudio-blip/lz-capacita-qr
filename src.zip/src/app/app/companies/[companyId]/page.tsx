import { redirect } from "next/navigation";

export default function CompaniesWorkerRedirect({
  params,
}: {
  params: { companyId: string; rut: string };
}) {
  redirect(
    `/app/company/${encodeURIComponent(params.companyId)}/workers/${encodeURIComponent(params.rut)}`
  );
}