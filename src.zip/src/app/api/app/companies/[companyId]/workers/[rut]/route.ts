import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import { cleanRut, isValidRut } from "@/lib/rut";

export const dynamic = "force-dynamic";

const UUID_RE =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

function isUuid(v: unknown) {
  return typeof v === "string" && UUID_RE.test(v.trim());
}

function getToken(req: NextRequest) {
  const auth = req.headers.get("authorization") || "";
  const m = auth.match(/^Bearer\s+(.+)$/i);
  return m?.[1] || null;
}

function sbAuthed(token: string) {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL!;
  const anon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;
  return createClient(url, anon, {
    global: { headers: { Authorization: `Bearer ${token}` } },
    auth: { persistSession: false },
  });
}

async function requireUser(req: NextRequest) {
  const token = getToken(req);
  if (!token) return { ok: false as const, status: 401, error: "Missing bearer token" };

  const supabase = sbAuthed(token);
  const { data: u, error: uerr } = await supabase.auth.getUser();
  if (uerr || !u?.user) return { ok: false as const, status: 401, error: "Unauthorized" };

  return { ok: true as const, supabase, user: u.user };
}

async function requireOwnedCompany(auth: { supabase: any; user: any }, companyId: string) {
  const { data, error } = await auth.supabase
    .from("companies")
    .select("id, owner_id, name, rut, address")
    .eq("id", companyId)
    .eq("owner_id", auth.user.id)
    .maybeSingle();

  if (error || !data) return null;
  return data;
}

type SessionRow = {
  id: string;
  code: string;
  topic: string | null;
  location: string | null;
  session_date: string | null;
  trainer_name: string | null;
  status: string | null;
  closed_at: string | null;
  created_at: string | null;
  pdf_path: string | null;
  pdf_generated_at: string | null;
};

type AttendanceRow = {
  created_at: string;
  rut: string;
  full_name: string | null;
  role: string | null;
  signature_path: string | null;
  session_id: string;
};

export async function GET(req: NextRequest, ctx: { params: { companyId: string; rut: string } }) {
  try {
    const auth = await requireUser(req);
    if (!auth.ok) return NextResponse.json({ error: auth.error }, { status: auth.status });

    const companyId = ctx.params.companyId;
    if (!isUuid(companyId)) return NextResponse.json({ error: "companyId inválido" }, { status: 400 });

    const rutParam = ctx.params.rut;
    const rutClean = cleanRut(rutParam);

    if (!rutClean || !isValidRut(rutClean)) {
      return NextResponse.json({ error: "RUT inválido" }, { status: 400 });
    }

    const owned = await requireOwnedCompany(auth, companyId);
    if (!owned) return NextResponse.json({ error: "Empresa no encontrada o sin acceso" }, { status: 404 });

    // Sesiones de la empresa
    const { data: sessions, error: sErr } = await auth.supabase
      .from("sessions")
      .select("id, code, topic, location, session_date, trainer_name, status, closed_at, created_at, pdf_path, pdf_generated_at")
      .eq("company_id", companyId)
      .eq("owner_id", auth.user.id);

    if (sErr) return NextResponse.json({ error: sErr.message }, { status: 400 });

    const sessionIds = (sessions ?? []).map((s: any) => s.id).filter(Boolean);
    if (!sessionIds.length) {
      return NextResponse.json({
        company: owned,
        worker: {
          rut: rutClean,
          full_name: null,
          role: null,
          first_seen_at: null,
          last_seen_at: null,
          attendances_total: 0,
          sessions_unique: 0,
        },
        attendances: [],
      });
    }

    // Asistencias del trabajador en esas sesiones
    const { data: attendees, error: aErr } = await auth.supabase
      .from("attendees")
      .select("created_at, rut, full_name, role, signature_path, session_id")
      .in("session_id", sessionIds)
      .eq("rut", rutClean)
      .order("created_at", { ascending: false });

    if (aErr) return NextResponse.json({ error: aErr.message }, { status: 400 });

    const attList: AttendanceRow[] = (attendees ?? []) as any;

    if (!attList.length) {
      return NextResponse.json({
        company: owned,
        worker: {
          rut: rutClean,
          full_name: null,
          role: null,
          first_seen_at: null,
          last_seen_at: null,
          attendances_total: 0,
          sessions_unique: 0,
        },
        attendances: [],
      });
    }

    const sessionMap = new Map<string, SessionRow>();
    for (const s of sessions ?? []) sessionMap.set((s as any).id, s as any);

    // Construir historial con info de sesión
    const attendances = attList
      .map((a) => ({
        created_at: a.created_at,
        rut: a.rut,
        full_name: a.full_name ?? null,
        role: a.role ?? null,
        signature_path: a.signature_path ?? null,
        session: sessionMap.get(a.session_id) ?? null,
      }))
      .filter((x) => !!x.session);

    const newest = attList[0]!;
    const oldest = attList[attList.length - 1]!;

    const uniqSessions = new Set(attList.map((a) => a.session_id));

    return NextResponse.json({
      company: owned,
      worker: {
        rut: rutClean,
        full_name: newest.full_name ?? null,
        role: newest.role ?? null,
        first_seen_at: oldest.created_at,
        last_seen_at: newest.created_at,
        attendances_total: attList.length,
        sessions_unique: uniqSessions.size,
      },
      attendances,
    });
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || "Server error" }, { status: 500 });
  }
}